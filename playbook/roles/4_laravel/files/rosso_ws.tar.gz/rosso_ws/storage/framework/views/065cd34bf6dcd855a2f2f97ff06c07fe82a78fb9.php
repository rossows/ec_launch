<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-info">
                    <div class="panel-heading">商品一覧</div>
                    <div class="panel-body">
                        <?php if(Session::has('info')): ?>
                            <div class="alert alert-success">
                                <a class="close" data-dismiss="alert">×</a>
                                <?php echo e(Session::get('info')); ?>

                            </div>
                        <?php elseif(Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <a class="close" data-dismiss="alert">×</a>
                                <?php echo e(Session::get('error')); ?>

                            </div>
                        <?php endif; ?>
                        <a class="btn btn-primary" href="<?php echo e(route('product::create')); ?>" role="button">新規登録</a>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>商品名</th>
                                    <th>ジャンル</th>
                                    <th>値段</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->getName()); ?></td>
                                        <td><?php echo e($product->getGenre()); ?></td>
                                        <td><?php echo e($product->getPrice()); ?></td>
                                        <td>
                                            <a class="btn btn-success" href="<?php echo e(route('product::edit', ['id' => $product->getId()])); ?>" role="button">編集</a>
                                        </td>
                                        <td>
                                            <form class="form-horizontal" method="POST" action="<?php echo e(route('product::destroy', ['id' => $product->getId()])); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <input name="_method" type="hidden" value="DELETE">
                                                <button type="submit" class="btn btn-danger">
                                                    削除
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>