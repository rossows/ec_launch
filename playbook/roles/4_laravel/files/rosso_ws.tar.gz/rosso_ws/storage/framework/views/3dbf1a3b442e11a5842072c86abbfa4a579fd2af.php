<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading">メニュー</div>
                <ul class="list-group">
                    <a href="<?php echo e(route('product::index')); ?>" class="list-group-item">商品一覧</a>
                    <a href="<?php echo e(route('product::create')); ?>" class="list-group-item">商品登録</a>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>